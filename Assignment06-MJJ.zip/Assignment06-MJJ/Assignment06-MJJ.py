# -------------------------------------------------#
# Title: Assignment06- Functions and Classes
# Dev:  MJJohnson
# Date:  February 19, 2018
# ChangeLog: (Who, When, What)
# RRoot, 11/02/2016, Created starting template
# MJJohnson, 02/10/2018 Added code to complete assignment 5
# MJJohnson  02/18/2018 created functions and classes for assignment06
# -------------------------------------------------#

#-------data-------------
objFileName = "/Users/melissajj/pythonclass/Module06/todo.txt"
strData = ""
blnStatus = False
dicRow = {}
lstTable = []
#-------data-------------

#-------Input/Output-------

class IO:
    @staticmethod
    def menuChoices():
        '''Displays a menu to user and gets their choice'''
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
        strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
        print()  # adding a new line
        return strChoice
    # ends menuChoices function

    @staticmethod
    def dispCurrentTasks():  # Step 3
        '''displays current items in the table'''
        print()
        print("Your To Do List Consists of: ")
        print("----------------------------------")
        for row in lstTable:
            print(row["Task"] + ", " + row["Priority"])
            print("----------------------------------")
    # end function

    @staticmethod
    def getTaskFromUser(): #3 getting task from user
        strTask = str(input("What is the task? ")).strip()
        strPriority = str(input("What is the priority? High/low ")).strip()
        return strTask, strPriority

    @staticmethod
    def getTaskToRemoveFromUser(): #getting task to delete
        return str((input("Which task would you like to remove? "))).lower()

    @staticmethod
    def getUserToSaveData():
        return str(input("Would you like to save this data? Type 'yes' or 'no'. ")).lower()
#-------Input/Output---------


#-------Processing-----------
class DataProcessor:

    @staticmethod
    def loadDatafromFile(objFileName):  # Step1
        '''This function loads data from a text file and stores it into a dictionary'''
        lstTable = []
        objFile = open(objFileName, "r")
        for line in objFile:  # reading each line in text file
            strData = line.split(",")
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)  # adding dictionary row to python list table
        objFile.close()
        return lstTable
    # the function loadDatafromFile ends here
   
    @staticmethod
    def insertTaskIntoList(taskName, priority, lstTable):
        taskIsOnList = False
        for toDoTask in lstTable:
            if (toDoTask["Task"].lower() == taskName.lower()):
                taskIsOnList = True
                break
        if not taskIsOnList:
            dicRow = {"Task": taskName, "Priority": priority}
            lstTable.append(dicRow)
            return True
        else:
            return False

    @staticmethod
    def deleteTaskFromList(taskName, lstTable):
        intRow = 0
        itemHasBeenRemoved = False
        while (intRow < len(lstTable)):
            if (taskName == str(list(dict(lstTable[intRow]).values())[0])):
                del lstTable[intRow]
                itemHasBeenRemoved = True
                break
            intRow += 1
        return itemHasBeenRemoved

    @staticmethod
    def saveDataToFile(objFileName, lstTable):
        objFile = open(objFileName, 'w')
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + ", " + dicRow["Priority"] + "\n")
        objFile.close()

#-------Processing-----------


#--------MAIN--------#
lstTable = DataProcessor.loadDatafromFile(objFileName) #step 1 loads data from file
#step 2 displays menu of choices to user
while (True):
    strChoice = IO.menuChoices()
    if (strChoice == '1'):
        #step3 displays current tasks to user
        IO.dispCurrentTasks()

    elif (strChoice == '2'):  # Step 4 - Add a new item to the list/Table
        # try to insert task into list
        # if insertion failed, print error message
        # request task name and priority
        taskName, priority = IO.getTaskFromUser()
        insertSuccess = DataProcessor.insertTaskIntoList(taskName, priority, lstTable)
        if not insertSuccess:
            print("The task is already on the to do list. ")
        IO.dispCurrentTasks()

    elif (strChoice == '3'):  # Step 5 - Remove a new item to the list/Table
        taskName = IO.getTaskToRemoveFromUser()
        deletionSuccess = DataProcessor.deleteTaskFromList(taskName, lstTable)
        if deletionSuccess:
            print("The task was removed from your to do list.")
        else:
            print("That task was not in your to do list.")

    elif (strChoice == '4'): # Save data to a file
        userOption = IO.getUserToSaveData()
        if userOption == 'yes':
            DataProcessor.saveDataToFile(objFileName, lstTable)
            print("The To Do List was saved.")
        else:
            print("The To Do list was not saved.")

    elif (strChoice == '5'):
        break
#---------------------------------------











