# -------------------------------------------------#
# Title: Assignment05- Lists and Dictionaries
# Dev:  MJJohnson
# Date:  February 10, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   MJJohnson, 02/10/2018 Added code to complete assignment 5
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------

objFileName = "/Users/melissajj/pythonclass/Module05/todo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
objFile = open(objFileName, "r")
for line in objFile:  # reading each line in text file
    strData = line.split(",")
    dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dicRow)  # adding dictionary row to python list table
objFile.close()

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    if (strChoice == '1'):  # Step 3 -Show the current items in the table
        print("Your To Do List Consists of: ")
        print("----------------------------------")
        for row in lstTable:
            print(row["Task"] + ", " + row["Priority"])
            print("----------------------------------")


    elif (strChoice == '2'):  # Step 4 - Add a new item to the list/Table
        strTask = (str(input("What is that task? ")).strip())

        taskIsOnList = False
        for toDoTask in lstTable:
            if (toDoTask["Task"].lower() == strTask.lower()) :
                taskIsOnList = True
                break

        if taskIsOnList:
            print("\nThat task is already on your to do list.")
        else:
            while True:
                strPriority = str(input("What is the priority? (High/Low) ")).strip()
                if strPriority.lower() == 'high' or strPriority.lower() == 'low':
                    break
                else:
                    print("Wrong priority value\n")

            dicRow = {"Task": strTask, "Priority": strPriority}
            lstTable.append(dicRow)
            print("\n", strTask, "has been added to your to do list.")

        print("\nYour To Do List Consists of: ")

        for dicRow in lstTable:
            print(dicRow)


    elif (strChoice == '3'):  # Step 5 - Remove a new item to the list/Table
        intRow = 0
        strTasktoRemove = str((input("Which task would you like to remove? "))).lower()
        blnItemRemoved = False
        while(intRow < len(lstTable)):
            if(strTasktoRemove == str(list(dict(lstTable[intRow]).values())[0])):
               del lstTable[intRow]
               blnItemRemoved = True
            intRow += 1
        if (blnItemRemoved == True):
            print("The task was removed from your to do list.")
        else:
            print("That task was not in your to do list.")


    elif (strChoice == '4'): # Save data to a file
        print("Your to do list is: ")
        for row in lstTable:
            print(row["Task"] + ", " + row["Priority"])
        usrSave = str(input("Would you like to save this data? Type 'yes' or 'no'.")).lower()
        if usrSave == "yes":
            objFile = open(objFileName, 'w')
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + ", " + dicRow["Priority"] + "\n")
            print("The To Do List was saved.")
            objFile.close()
        else:
            print("The To Do list was not saved.")

    elif (strChoice == '5'):
        break
